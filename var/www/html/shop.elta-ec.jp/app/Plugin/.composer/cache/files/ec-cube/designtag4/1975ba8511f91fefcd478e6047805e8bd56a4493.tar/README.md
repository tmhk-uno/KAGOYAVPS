# DesignTag4

## 商品一覧ページにタグを表示する方法

Product/list.twigのタグを表示したい場所に下記のコードを記載してください。

` {{ include('@DesignTag4/tag_list.twig', ignore_missing = true) }}`