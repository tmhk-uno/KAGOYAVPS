## 1.19.0

* For the `facebook` client, the `graph_api_version` is now *required*. It previously
  defaulted to `v2.5`.

## 1.18.0

* [BC Break] If you're using the "discord" client, we've migrated to use a newer, not abandoned client - see #90
