<?php

namespace Auth0\SDK\Exception;

/**
 * Represents all errors returned by the server
 */
class ApiException extends \Exception
{

}
